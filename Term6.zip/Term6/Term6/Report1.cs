﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Extra Namespace
using System.Data.SqlClient;

namespace Term6
{
    public partial class Report1 : Form
    {
        public Report1()
        {
            InitializeComponent();
        }

        private void BindGrid()
        {
            string constring = @"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\Ajay_2GI20MC005\C#LabPrograms\partB\Term6\Term6\STUDENT.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand cmd = new SqlCommand("SELECT * FROM STUDENT WHERE CID LIKE '"+ textBox1.Text+"%'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            {
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Enter the course ID");
            }
            else
            {
                BindGrid();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
