﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//
using System.Data.OleDb;

namespace Term2
{
    public partial class BookIssue : Form
    {
        public BookIssue()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BookIssue_Load(object sender, EventArgs e)
        {
            BindGrid();

            //fills 1st combobox
            OleDbConnection odb = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb");
            odb.Open();
            string strCmd = "select USN from STUDENT";
            OleDbCommand cmd = new OleDbCommand(strCmd, odb);
            OleDbDataAdapter da = new OleDbDataAdapter(strCmd, odb);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            odb.Close();

            comboBox1.DisplayMember = "USN";
            comboBox1.ValueMember = "USN";
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.Enabled = true;

            //fills 1st combobox
            OleDbConnection odb1 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb");
            odb1.Open();
            string strCmd1 = "select BID from BOOK";
            OleDbCommand cmd1 = new OleDbCommand(strCmd1, odb1);
            OleDbDataAdapter da1 = new OleDbDataAdapter(strCmd1, odb1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            cmd1.ExecuteNonQuery();
            odb1.Close();

            comboBox2.DisplayMember = "BID";
            comboBox2.ValueMember = "BID";
            comboBox2.DataSource = ds1.Tables[0];
            comboBox2.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Enabled = true;
            comboBox2.Enabled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection odb = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb");
            odb.Open();
            OleDbCommand odcom = new OleDbCommand("INSERT INTO BOOKISSUE VALUES ('" + comboBox1.Text + "'," + comboBox2.Text + ",'" + dateTimePicker1.Value.Date + "')", odb);
            odcom.ExecuteNonQuery();
            odb.Close();
            dataGridView1.Rows.Clear();
            //continue from heres
            BindGrid();
            comboBox1.Enabled = false;
            comboBox2.Enabled = false;
        }

        private void BindGrid()
        {
            string strProvider = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb";
            string strSql = "SELECT * FROM BOOKISSUE";
            OleDbConnection con = new OleDbConnection(strProvider);
            OleDbCommand cmd = new OleDbCommand(strSql, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            OleDbDataReader dr = cmd.ExecuteReader();
            int columnCount = dr.FieldCount;
            for (int i = 0; i < columnCount; i++)
            {
                dataGridView1.Columns.Add(dr.GetName(i).ToString(), dr.GetName(i).ToString());
            }

            string[] rowData = new string[columnCount];
            while (dr.Read())
            {
                for (int k = 0; k < columnCount; k++)
                {
                    if (dr.GetFieldType(k).ToString() == "System.Int32")
                    {
                        rowData[k] = dr.GetInt32(k).ToString();
                    }
                    if (dr.GetFieldType(k).ToString() == "System.String")
                    {
                        rowData[k] = dr.GetString(k);
                    }
                    if (dr.GetFieldType(k).ToString() == "System.DateTime")
                    {
                        rowData[k] = dr.GetDateTime(k).ToString();
                    }
                }
                dataGridView1.Rows.Add(rowData);
            }
            con.Close();
        }
    }
}
