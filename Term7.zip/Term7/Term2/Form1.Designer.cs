﻿namespace Term2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.courseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courseToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookIssueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.booksBasedOnCourseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.booksBasedOnStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.booksBasedOnDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.courseToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(567, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // courseToolStripMenuItem
            // 
            this.courseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.courseToolStripMenuItem1,
            this.bookToolStripMenuItem,
            this.studentToolStripMenuItem,
            this.bookIssueToolStripMenuItem});
            this.courseToolStripMenuItem.Name = "courseToolStripMenuItem";
            this.courseToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.courseToolStripMenuItem.Text = "File";
            // 
            // courseToolStripMenuItem1
            // 
            this.courseToolStripMenuItem1.Name = "courseToolStripMenuItem1";
            this.courseToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.courseToolStripMenuItem1.Text = "Course";
            this.courseToolStripMenuItem1.Click += new System.EventHandler(this.courseToolStripMenuItem1_Click);
            // 
            // bookToolStripMenuItem
            // 
            this.bookToolStripMenuItem.Name = "bookToolStripMenuItem";
            this.bookToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.bookToolStripMenuItem.Text = "Book";
            this.bookToolStripMenuItem.Click += new System.EventHandler(this.bookToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.studentToolStripMenuItem.Text = "Student";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // bookIssueToolStripMenuItem
            // 
            this.bookIssueToolStripMenuItem.Name = "bookIssueToolStripMenuItem";
            this.bookIssueToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.bookIssueToolStripMenuItem.Text = "BookIssue";
            this.bookIssueToolStripMenuItem.Click += new System.EventHandler(this.bookIssueToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.booksBasedOnCourseToolStripMenuItem,
            this.booksBasedOnStudentToolStripMenuItem,
            this.booksBasedOnDateToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // booksBasedOnCourseToolStripMenuItem
            // 
            this.booksBasedOnCourseToolStripMenuItem.Name = "booksBasedOnCourseToolStripMenuItem";
            this.booksBasedOnCourseToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.booksBasedOnCourseToolStripMenuItem.Text = "Books Based on Course";
            this.booksBasedOnCourseToolStripMenuItem.Click += new System.EventHandler(this.booksBasedOnCourseToolStripMenuItem_Click);
            // 
            // booksBasedOnStudentToolStripMenuItem
            // 
            this.booksBasedOnStudentToolStripMenuItem.Name = "booksBasedOnStudentToolStripMenuItem";
            this.booksBasedOnStudentToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.booksBasedOnStudentToolStripMenuItem.Text = "Books Based on Student";
            this.booksBasedOnStudentToolStripMenuItem.Click += new System.EventHandler(this.booksBasedOnStudentToolStripMenuItem_Click);
            // 
            // booksBasedOnDateToolStripMenuItem
            // 
            this.booksBasedOnDateToolStripMenuItem.Name = "booksBasedOnDateToolStripMenuItem";
            this.booksBasedOnDateToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.booksBasedOnDateToolStripMenuItem.Text = "Books Based on date";
            this.booksBasedOnDateToolStripMenuItem.Click += new System.EventHandler(this.booksBasedOnDateToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 512);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "LIBRARY INFORMATION";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem courseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem courseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookIssueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booksBasedOnCourseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booksBasedOnStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booksBasedOnDateToolStripMenuItem;
    }
}

