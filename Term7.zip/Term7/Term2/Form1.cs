﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Term2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void courseToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Course newChild = new Course();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Book newChild = new Book();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Student newChild = new Student();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void bookIssueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookIssue newChild = new BookIssue();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void booksBasedOnCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report1 newChild = new Report1();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void booksBasedOnStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report2 newChild = new Report2();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }

        private void booksBasedOnDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report3 newChild = new Report3();
            newChild.MdiParent = this;
            newChild.WindowState = FormWindowState.Maximized;
            newChild.Show();
        }
    }
}
