﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//
using System.Data.OleDb;

namespace Term2
{
    public partial class Report2 : Form
    {
        public Report2()
        {
            InitializeComponent();
        }

        private void Report2_Load(object sender, EventArgs e)
        {
            OleDbConnection odb = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb");
            odb.Open();
            string strCmd = "select USN from STUDENT";
            OleDbCommand cmd = new OleDbCommand(strCmd, odb);
            OleDbDataAdapter da = new OleDbDataAdapter(strCmd, odb);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            odb.Close();

            comboBox1.DisplayMember = "USN";
            comboBox1.ValueMember = "USN";
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void BindGrid()
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\aj\\Downloads\\Output_6_7_8_new\\Term7\\Term7\\STUDENT.mdb");

            OleDbCommand cmd = new OleDbCommand("SELECT BOOK.BID, BOOK.TITLE, BOOKISSUE.USN, BOOKISSUE.IDATE from BOOK INNER JOIN BOOKISSUE ON BOOK.BID = BOOKISSUE.BID WHERE (((BOOKISSUE.USN)= '" + comboBox1.Text + "'))", con);
            cmd.CommandType = CommandType.Text;
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            {
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
